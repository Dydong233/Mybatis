package com.dyd.dao;

import com.dyd.pojo.Student;

import java.util.List;

public interface StudentMapper {

}
